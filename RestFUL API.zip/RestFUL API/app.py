import os
from bson.json_util import dumps,loads

import pymongo
from flask import Flask, jsonify, request

# SET DB
client=pymongo.MongoClient("mongodb+srv://roger:"+os.environ["dbpass"]+"@cluster0-pmgbq.mongodb.net/slangs?retryWrites=true&w=majority")
db=client.slangs
collection=db.slangs

app=Flask(__name__)

@app.route("/")
def api_get():
    objects=collection.find()
    output=[]
    for obj in objects:
        output.append({"palabra": obj["palabra"], "definicion": obj["definicion"]})
    return jsonify({"resultado": output})
    

@app.route("/slang/<palabra>")
def api_show(palabra):
    obj=collection.find_one({"palabra":palabra})
    output=[]
    if obj:
        output.append({"palabra": obj["palabra"], "definicion": obj["definicion"]})
        return jsonify({"message": "Slang Encontrado"},{"resultado": output})
    else:
        return jsonify({"message": "Slang Inexistente"})

@app.route("/add_slang",methods=["POST"])
def api_post():
    output=[]
    new_slang={ 
        "palabra": request.json["palabra"],
        "definicion": request.json["definicion"]
    }
    collection.insert_one(new_slang)
    objects=collection.find()
    for obj in objects:
        output.append({"palabra": obj["palabra"], "definicion": obj["definicion"]})
    return jsonify({"message": "Slang Añadido exitosamente"}, {"slangs": output })

@app.route("/edit_slang/<palabra>", methods=["PUT"])
def api_put(palabra):
    nueva_palabra=request.json["palabra"]
    nueva_definicion=request.json["definicion"]
    output=[]
    obj=collection.find_one_and_update({"palabra": palabra}, {"$set":{"palabra":nueva_palabra, "definicion": nueva_definicion} })
    if obj:
        word=collection.find_one({"palabra":nueva_palabra})
        output.append({"palabra": word["palabra"], "definicion": word["definicion"]})
    else:
        return jsonify({"message": "Not found"})
    return jsonify({"message": "Slang actualizado exitosamente" ,"resultado": output})

@app.route("/delete_slang/<palabra>", methods=["DELETE"])
def api_delete(palabra):
    obj=collection.find_one_and_delete({"palabra":palabra})
    output=[]
    if obj!=None:
        return jsonify({"message": "Slang eliminado con exito"})
    else:
        return jsonify({"message": "Slang no encontrado"})

if __name__ == "__main__":
    app.run(debug=True)