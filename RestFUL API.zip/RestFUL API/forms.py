from flask_wtf import FlaskForm
from wtforms import StringField,SubmitField

class Add_Slang(FlaskForm):
    palabra=StringField("Palabra")
    definicion=StringField("Definicion")
    submit=SubmitField()